package com.tonynubmc.obsidianatnt;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Blocks;
import net.minecraft.entity.TntEntity;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.entity.player.PlayerEntity;

public class ObsidianUseHandler implements UseBlockCallback {
    @Override
    public ActionResult interact(PlayerEntity player, World world, Hand hand, net.minecraft.util.hit.BlockHitResult hitResult) {
        if (!world.isClient &&
            player.isSneaking() &&
            player.getStackInHand(hand).getItem() == Items.FLINT_AND_STEEL &&
            world.getBlockState(hitResult.getBlockPos()).isOf(Blocks.OBSIDIAN)) {

            BlockPos pos = hitResult.getBlockPos().up();

            ObsidianTntEntity entity = new ObsidianTntEntity(world, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
            world.spawnEntity(entity);

            player.getStackInHand(hand).damage(1, player, (p) -> p.sendToolBreakStatus(hand));
            return ActionResult.SUCCESS;
        }

        return ActionResult.PASS;
    }
}
