package com.tonynubmc.obsidianatnt;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Obsidianatnt implements ModInitializer {
    public static final String MOD_ID = "obsidianatnt";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Iniciando Obsidianatnt por TonyNubmc");
        UseBlockCallback.EVENT.register(new ObsidianUseHandler());
    }
}
