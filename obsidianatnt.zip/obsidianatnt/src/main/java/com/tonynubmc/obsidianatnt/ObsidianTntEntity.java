package com.tonynubmc.obsidianatnt;

import net.minecraft.entity.TntEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.world.World;

public class ObsidianTntEntity extends TntEntity {

    public ObsidianTntEntity(World world, double x, double y, double z) {
        super(net.minecraft.entity.EntityType.TNT, world);
        this.setPosition(x, y, z);
        this.setFuse(60);
    }

    @Override
    protected void explode() {
        world.createExplosion(this, this.getX(), this.getY(), this.getZ(), 3.0f, World.ExplosionSourceType.TNT);
    }

    @Override
    public boolean shouldRender(double distance) {
        return true;
    }

    @Override
    public boolean isInvulnerableTo(DamageSource damageSource) {
        return true;
    }
}
