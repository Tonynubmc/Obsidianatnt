@echo off
gradlew wrapper
